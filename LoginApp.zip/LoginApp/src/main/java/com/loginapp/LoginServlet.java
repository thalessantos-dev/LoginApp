package com.loginapp;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.IOException;
import java.util.HashMap;

public class LoginServlet extends HttpServlet {
    private final HashMap<String, String> users = new HashMap<>();

    @Override
    public void init() {
        users.put("admin", "1234");
        users.put("usuario", "senha");
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String usuario = request.getParameter("username");
        String senha = request.getParameter("password");

        if (users.containsKey(usuario) && users.get(usuario).equals(senha)) {
            RequestDispatcher dispatcher = request.getRequestDispatcher("welcome.jsp");
            dispatcher.forward(request, response);
        } else {
            RequestDispatcher dispatcher = request.getRequestDispatcher("error.jsp");
            dispatcher.forward(request, response);
        }
    }
}